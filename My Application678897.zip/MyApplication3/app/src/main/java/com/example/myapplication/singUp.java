package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class singUp extends AppCompatActivity implements View.OnClickListener {

    Button singedUpBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sing_up);

        singedUpBtn = (Button)findViewById(R.id.button);
        singedUpBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if (view == singedUpBtn)
        {

            startActivity(new Intent(this, home.class));

        }

    }
}