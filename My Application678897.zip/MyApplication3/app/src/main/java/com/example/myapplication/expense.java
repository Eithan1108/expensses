package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class expense extends AppCompatActivity implements View.OnClickListener {

    ImageButton addButton;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {


        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_reports,menu);
        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id = item.getItemId();

        if (id == R.id.action_reports) {

            startActivity(new Intent(this, reports2.class));

        } else if (id == R.id.action_settings) {

            startActivity(new Intent(this, setings.class));

        } else if (id == R.id.action_home) {

            startActivity(new Intent(this, home.class));

        }

        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);

        addButton = (ImageButton) findViewById(R.id.imageButton4);
        addButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == addButton)
        {

            startActivity(new Intent(this, addExpense.class));

        }
    }
}