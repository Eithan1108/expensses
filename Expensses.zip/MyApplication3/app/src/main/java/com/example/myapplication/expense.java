package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;

public class expense extends AppCompatActivity implements View.OnClickListener {



    ImageButton addButton,addButton11,addButton12,addButton13;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {


        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_reports,menu);
        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        int id = item.getItemId();

        if (id == R.id.action_reports) {

            startActivity(new Intent(this, reports2.class));

        } else if (id == R.id.action_settings) {

            startActivity(new Intent(this, setings.class));

        } else if (id == R.id.action_home) {

            startActivity(new Intent(this, home.class));

        }

        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense);


        addButton11 = (ImageButton)findViewById(R.id.imageButton2);
        addButton11.setOnClickListener(this);
        addButton12 = (ImageButton)findViewById(R.id.imageButton3);
        addButton12.setOnClickListener(this);
        addButton13 = (ImageButton)findViewById(R.id.imageButton4);
        addButton13.setOnClickListener(this);




        addButton = (ImageButton) findViewById(R.id.imageButton);
        addButton.setOnClickListener(this);

        ArrayList<Expensse> expensseArray = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            expensseArray.add(new Expensse (Category.Name3,
                    1284.64,
                    2021,
                    "Pick"
            ));
        }

        RecyclerView recyclerview = findViewById(R.id.recyclerview_expensse);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerview.setLayoutManager(layoutManager);


        ExpensseAdapter expensseAdapter = new ExpensseAdapter(expensseArray);
        recyclerview.setAdapter(expensseAdapter);




    }

    @Override
    public void onClick(View view) {
        if (view == addButton11||view == addButton12||view == addButton13)
        {

            startActivity(new Intent(this, editExpense.class));

        } else if (view == addButton) {
            startActivity(new Intent(this, addExpense.class));

        }
    }
}