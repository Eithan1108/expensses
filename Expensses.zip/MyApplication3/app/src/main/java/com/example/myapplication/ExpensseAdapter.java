package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;







public class ExpensseAdapter extends RecyclerView.Adapter<ExpensseAdapter.ExpensseViewHolder> {

    private ArrayList<Expensse> expenssesList;

    public ExpensseAdapter(ArrayList<Expensse> expenssesList) {
        this.expenssesList = expenssesList;
    }

    @NonNull
    @Override
    public ExpensseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View expensseView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycleritem_expensse, parent,false);
        return new ExpensseViewHolder(expensseView);
    }

    @Override
    public void onBindViewHolder(@NonNull ExpensseViewHolder holder, int position) {

        Expensse current = expenssesList.get(position);
        holder.dateView.setText(current.getDate());
        holder.details.setText(current.getPicName());


    }

    @Override
    public int getItemCount() {
        return expenssesList.size();
    }


    public static class ExpensseViewHolder extends RecyclerView.ViewHolder {

        public TextView dateView;
        public ImageButton edit;
        public TextView details;

        public ExpensseViewHolder (@NonNull View itemView) {
            super(itemView);

            dateView = itemView.findViewById(R.id.textView3);
            edit = itemView.findViewById(R.id.imageButton5);
            details = itemView.findViewById(R.id.textView5);

        }
    }
}
