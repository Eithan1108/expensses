package com.example.myapplication;
public enum Category {
    Name1,
    Name2,
    Name3,
    Name4,
    Name5,
    Name6
}
