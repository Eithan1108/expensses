package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Date;

public class Expensse  {

    private Category category;
    private double amount;
    private int date;
    private String picName;

    public Expensse() {
    }



    public Expensse(Category category, double amount, int date, String picName) {
        this.category = category;
        this.amount = amount;
        this.date = date;
        this.picName = picName;

    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public String getPicName() {
        return picName;
    }

    public void setPicName(String picName) {
        this.picName = picName;
    }

    @Override
    public String toString() {
        return "Expensse{" +
                "category=" + category +
                ", amount=" + amount +
                ", date=" + date +
                ", picName='" + picName + '\'' +
                '}';
    }











}
